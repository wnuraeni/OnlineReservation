<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
if ( !defined('BASEPATH')) exit ('No direct script access.');


 class reservasi_controller extends CI_Controller{
     var $time;
     var $times;
     function __construct(){
         parent:: __construct();
         $this->load->model('lapangan_model','',TRUE);
         $this->times=array('09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00');
         $this->time=array('09:00-10:00','10:00-11:00','11:00-12:00','12:00-13:00','13:00-14:00','14:00-15:00','15:00-16:00','16:00-17:00');
         $this->load->model('reservasi_model','',TRUE);
          $this->load->model('inventori_model','',TRUE);
          $this->load->model('promosi_model','',TRUE);

     }

 function index($offset=null){
    if($this->input->post('search')){
            $like=array($this->input->post('kategori')=>$this->input->post('keyword'));
        }else {
            $like=null;
        }
       $where=null;
       $config['base_url']=base_url().'kasir/reservasi_controller/index/';
       $config['total_rows']=$this->reservasi_model->ambil_total_reservasi($like);
       $config['per_page']=10;
       $config['uri_segment']=4;
       $config['use_page_numbers']=TRUE;
       $this->pagination->initialize($config);
       if($offset != NULL){
           $offset=($offset-1)*10;
       }else {
           $offset=$offset;
       }

    $data_db=$this->reservasi_model->ambil_reservasi($like,10,$offset);
    $data['sewa']=$data_db;
    $data['title']='Daftar Reservasi';
    $data['content']='kasir/daftar_reservasi';
    $this->load->view('kasir/template_admin',$data);
 }


 function book($jam=null,$tanggal=null,$nama_lapangan=null){
         $this->session->set_userdata('backlink',$this->uri->uri_string());
         $this->session->userdata('backlink');
         if($this->input->post('sewa')){
             $data_reservasi=array('id_lapangan'=>$this->input->post('id_lapangan'),'nama_lapangan'=>$this->input->post('nama_lapangan'),
                                   'id_member'=>$this->input->post('id_member'), 'nama'=>$this->input->post('nama_pelanggan'),
                                    'alamat'=>$this->input->post('alamat_pelanggan'), 'telepon'=>$this->input->post('telepon_pelanggan'),
                                     'jam'=>$this->input->post('jam'), 'tanggal_booking'=>$this->input->post('tanggal'), 'lama_pemakaian'=>$this->input->post('lama_sewa'),
                                     'harga_lapangan'=>$this->input->post('harga_sewa_lapangan'), 'status_booking'=>'booking');
           if($id_reservasi=$this->reservasi_model->pesan($data_reservasi)){
               redirect(base_url().'kasir/reservasi_controller/konfirmasi/'.$id_reservasi);

           }else {
               echo ' ';
           }


         }
         $id_lapangan=$this->lapangan_model->ambil_id_lapangan(array('nama_lapangan'=>$nama_lapangan));
         $id_lap=$id_lapangan[0]->id_lapangan;
         $data['promosi']=$this->promosi_model->ambil_promosi(array('periode_awal <= '=>date('Y-m-d'),'periode_akhir >= '=>date('Y-m-d')));
         $data['nama_lapangan']=$nama_lapangan;
         $data['tanggal']=$tanggal;
         $data['title']='Reservasi';
         $data['jam']=$this->times[$jam];
         $data['id_lapangan']=$id_lap;
         $data['index_jam']=$jam;
         $harga_lapangan=$this->lapangan_model->ambil_lapangan(array('id_lapangan'=>$id_lap));
         $data['harga_sewa_lapangan']=$harga_lapangan[0]->sewa_lapangan;
         $data['content']='kasir/form_reservasi';
         $this->load->view('kasir/template_admin',$data);

     }


     function konfirmasi($id_reservasi){
         $data['reservasi']=$this->reservasi_model->ambil_reservasi(array('id_booking'=>$id_reservasi));
         $data['title']='konfirmasi reservasi';
         $data['content']='kasir/konfirmasi_reservasi';
         $this->load->view('kasir/template_admin',$data);
     }


 function checkin($id_booking){
     $this->session->set_flashdata('checkin',$this->uri->uri_string());
     //$this->reservasi_model->checkin($id_booking);
     $this->session->set_userdata('id_booking',$id_booking);
     $data['promosi']=$this->promosi_model->ambil_promosi(array('periode_awal <= '=>date('Y-m-d'),'periode_akhir >= '=>date('Y-m-d')));
     $data['barang']=$this->inventori_model->generate_image_inventori();
     $data['reservasi']=$this->reservasi_model->ambil_reservasi(array('id_booking'=>$id_booking));
     $data['title']='Form Sewa';
     $data['content']='kasir/form_sewa2';
     $this->load->view('kasir/template_admin',$data);
 }

 function batal($id_booking){
     $this->reservasi_model->batal($id_booking,array('status_booking'=>'batal'));
     redirect(base_url().'kasir/reservasi_controller/index');
 }
 }

?>
