<?php
if ( !defined('BASEPATH')) exit ('No direct script access.');


 class index extends CI_Controller {

     function __construct (){
             parent :: __construct();
             $this->load->model('login_model','',TRUE);

     }

     function index(){
         $data['content']='kasir/home';
         $this->load->view('kasir/template_admin',$data);
         
     }

     function penyewaan(){
         $data['content']='kasir/penyewaan';
         $this->load->view('kasir/template_admin',$data);

     }

     function logout(){
        $this->session->unset_userdata('iskasir');
        $this->session->unset_userdata('kasirname');
        $this->session->unset_userdata('idkasir');
        $this->session->unset_userdata('accesskasir');
        redirect(base_url().'admin');
    }

     
 }










?>