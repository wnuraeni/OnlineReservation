<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
//if ( !defined('BASEPATH')) exit ('No direct script access.');

 class reservasi_controller extends CI_Controller{
     var $time;
     var $times;
     function __construct(){
         parent:: __construct();
         $this->load->model('lapangan_model','',TRUE);
         $this->times=array('09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00','17:00');
         $this->time=array('09:00-10:00','10:00-11:00','11:00-12:00','12:00-13:00','13:00-14:00','14:00-15:00','15:00-16:00','16:00-17:00');
         $this->load->model('reservasi_model','',TRUE);
          $this->load->model('inventori_model','',TRUE);
          $this->load->model('promosi_model','',TRUE);
          $this->load->model('pembayaran_model','',TRUE);

     }

 function index($offset=null){
    if($this->input->post('search')){
            $like=array($this->input->post('kategori')=>$this->input->post('keyword'));
        }else {
            $like=null;
        }
       $where=null;
       $config['base_url']=base_url().'index.php/kasir/reservasi_controller/index/';
       $config['total_rows']=$this->reservasi_model->ambil_total_reservasi($like);
       $config['per_page']=10;
       $config['uri_segment']=4;
       $config['use_page_numbers']=TRUE;
       $this->pagination->initialize($config);
       if($offset != NULL){
           $offset=($offset-1)*10;
       }else {
           $offset=$offset;
       }

    $data_db=$this->reservasi_model->ambil_reservasi($like,10,$offset);
    $data['sewa']=$data_db;
    $data['title']='Daftar Reservasi';
    $data['content']='kasir/daftar_reservasi';
    $this->load->view('kasir/template_admin',$data);
 }


 function book($jam=null,$tanggal=null,$nama_lapangan=null){
         $this->session->set_userdata('backlink',$this->uri->uri_string());
         $this->session->userdata('backlink');
         if($this->input->post('sewa')){
             $data_reservasi=array('id_lapangan'=>$this->input->post('id_lapangan'),'nama_lapangan'=>$this->input->post('nama_lapangan'),
                                   'id_member'=>$this->input->post('id_member'), 'nama'=>$this->input->post('nama_pelanggan'),
                                    'alamat'=>$this->input->post('alamat_pelanggan'), 'telepon'=>$this->input->post('telepon_pelanggan'),
                                     'jam'=>$this->input->post('jam'), 'tanggal_booking'=>$this->input->post('tanggal'), 'lama_pemakaian'=>$this->input->post('lama_sewa'),
                                     'harga_lapangan'=>$this->input->post('harga_sewa_lapangan'), 'status_booking'=>'booking');
           if($id_reservasi=$this->reservasi_model->pesan($data_reservasi)){
               redirect(base_url().'index.php/kasir/reservasi_controller/konfirmasi/'.$id_reservasi);

           }else {
               echo ' ';
           }


         }
         
         $id_lapangan=$this->lapangan_model->ambil_id_lapangan(array('nama_lapangan'=>$nama_lapangan));
         $id_lap=$id_lapangan[0]->id_lapangan;
         $data_lapangan = $this->lapangan_model->ambil_lapangan(array('nama_lapangan'=>$nama_lapangan));
         $jenis_lapangan = $data_lapangan[0]->jenis_lapangan;
         $lapangan =  $this->lapangan_model->ambil_lapangan_booking($jenis_lapangan,$tanggal,$jam);
         $lama = 0;
         $waktu=array('09:00','10:00','11:00','12:00','13:00','14:00','15:00','16:00');
         for($i=$jam;$i<8;$i++){
            if(isset($lapangan[$waktu[$i]][$tanggal][$nama_lapangan])){
                break;
            }else{
                $lama++;
            }
         }
         $data['promosi']=$this->promosi_model->ambil_promosi(array('periode_awal <= '=>date('Y-m-d'),'periode_akhir >= '=>date('Y-m-d')));
         $data['nama_lapangan']=$nama_lapangan;
         $data['tanggal']=$tanggal;
         $data['title']='Reservasi';
         $data['jam']=$this->times[$jam];
         $data['id_lapangan']=$id_lap;
         $data['index_jam']=$jam;
         $data['lama_sewa'] = $lama;
         $harga_lapangan=$this->lapangan_model->ambil_lapangan(array('id_lapangan'=>$id_lap));
         $data['harga_sewa_lapangan']=$harga_lapangan[0]->sewa_lapangan;
         $data['content']='kasir/form_reservasi';
         $this->load->view('kasir/template_admin',$data);

     }


     function konfirmasi($id_reservasi){
         $data['reservasi']=$this->reservasi_model->ambil_reservasi(array('id_booking'=>$id_reservasi));
         $data['title']='konfirmasi reservasi';
         $data['id_reservasi']=$id_reservasi;
         $data['content']='kasir/konfirmasi_reservasi';
         $this->load->view('kasir/template_admin',$data);
     }
     function konfirmasi_via_email(){
         $id_reservasi = $this->input->post('id_booking');
         $email = $this->input->post('email');
         $reservasi = $this->reservasi_model->ambil_reservasi(array('id_booking'=>$id_reservasi));
         $html = '<h5>Terima Kasih Telah Melakukan Pesanan</h5>
                <p>Silakan Datang 30 menit Sebelum Waktu yang telah Anda pesan</p>
                <p>Simpan Bukti dibawah untuk Bukti Konfirmasi Pesanan</p>

                <table>
                <tr><td>No Booking</td><td><?php echo $reservasi[0]->id_booking;?></td></tr>
                <tr><td>Nama Lapangan</td><td><?php echo $reservasi[0]->nama_lapangan;?></td></tr>
                <tr><td>Tanggal Sewa</td><td><?php echo $reservasi[0]->tanggal_booking;?></td></tr>
                <tr><td>Jam Sewa</td><td><?php echo $reservasi[0]->jam;?></td></tr>
                <tr><td>Lama Pemakaian</td><td><?php echo $reservasi[0]->lama_pemakaian;?></td></tr>
                <tr><td>Nama</td><td><?php echo $reservasi[0]->nama;?></td></tr>
                <tr><td>Alamat</td><td><?php echo $reservasi[0]->alamat;?></td></tr>
                <tr><td>Telepon</td><td><?php echo $reservasi[0]->telepon;?></td></tr>
                </table>';
         $this->load->library('email');
         $this->email->from('admin@localhost','Administrator');
         $this->email->to($email);
         $this->email->subject('Konfirmasi Reservasi Lapangan');
         $this->email->message($html);
         if($this->email->send()){
                 echo '<script>alert("Email telah dikirim")</script>';
                 redirect(base_url().'index.php/kasir/reservasi_controller/konfirmasi/'.$id_reservasi);
         }
         else{
              echo '<script>alert("Email gagal dikirim")</script>';
         }

     }


 function checkin($id_booking){
     $this->session->set_flashdata('checkin',$this->uri->uri_string());
     $this->reservasi_model->checkin($id_booking);
     $this->session->set_userdata('id_booking',$id_booking);
     //$data['promosi']=$this->promosi_model->ambil_promosi(array('periode_awal <= '=>date('Y-m-d'),'periode_akhir >= '=>date('Y-m-d')));
     //$data['barang']=$this->inventori_model->generate_image_inventori();
    $data_reservasi=$this->reservasi_model->ambil_reservasi(array('id_booking'=>$id_booking));
     //$data['title']='Form Sewa';
     $store2dblapangan=array('id_lapangan'=>$data_reservasi[0]->id_lapangan,
                            'harga_total_lapangan'=>$data_reservasi[0]->harga_lapangan * $data_reservasi[0]->lama_pemakaian );

     $id_sewa_lapangan=$this->lapangan_model->sewa_lapangan($store2dblapangan);
     $jumlah_dibayar=$data_reservasi[0]->harga_lapangan * $data_reservasi[0]->lama_pemakaian;
     $telah_dibayar=$this->reservasi_model->ambil_pembayaran(array('id_booking'=>$id_booking));;

     $store2db=array('id_pelanggan'=>$data_reservasi[0]->id_member,
                    'id_penyewaan_lapangan'=>$id_sewa_lapangan,
        'id_karyawan'=>$this->session->userdata('idkasir'),
         'nama_pelanggan'=>$data_reservasi[0]->nama,
        'tanggal_penyewaan'=>$data_reservasi[0]->tanggal_booking,
        'jam'=>$data_reservasi[0]->jam,
         'lama_pemakaian'=>$data_reservasi[0]->lama_pemakaian,
         'jumlah_dibayar'=>$jumlah_dibayar,
       'total_pembayaran'=>$telah_dibayar[0]->total_pembayaran );
     $id_penyewaan=$this->pembayaran_model->detail_pembayaran($store2db);
     $data_db=$this->pembayaran_model->ambil_detail_pembayaran($id_penyewaan);
     $data['title']='Bukti Pembayaran';
     $data['bukti']=$data_db;
     $data['kembali']=0;
     $data['content']='kasir/bukti_pembayaran';
    
     $this->load->view('kasir/template_admin',$data);
 }
//pembatalan satu booking
 function batal($id_booking){

     $this->reservasi_model->batal($id_booking,array('status_booking'=>'batal'));
     redirect(base_url().'index.php/kasir/reservasi_controller/index');
 }
 //pembatalan beberapa booking otomatis
 function pembatalan(){
    $ids = $this->input->post('id');
    $this->reservasi_model->pembatalan($ids);
    redirect(base_url('index.php/kasir/reservasi_controller/index'));
 }
function cek_reservasi(){
    //$this->reservasi_model->cek_reservasi(date('Y-m-d'),date('H:i:s'));
    //ambil data reservasi yang belum pada bayar
    $data_db=$this->reservasi_model->cek_reservasi();
    $data['sewa']=$data_db;
    $data['title']='Daftar Reservasi';
    $data['content']='kasir/daftar_reservasi';
    $this->load->view('kasir/template_admin',$data);
}
function cek_dp(){
    $data_db=$this->reservasi_model->cek_dp();
    $data['sewa']=$data_db;
    $data['title']='Daftar Reservasi';
    $data['content']='kasir/daftar_reservasi';
    $this->load->view('kasir/template_admin',$data);
}

  function pembayaran($id_reservasi){
    $this->form_validation->set_rules('id_booking','No Booking','required');
    $this->form_validation->set_rules('tgl_pmbyrn','Tanggal Pembayaran','required');
    $this->form_validation->set_rules('jml_pmbyrn','Jumlah Pembayaran', 'required|numeric');
    $this->form_validation->set_rules('jenis_pmbyrn','Jenis pembayaran','required');

    if($this->form_validation->run()== true){
    $store2db = array(
            'id_booking'=>$this->input->post('id_booking'),
            'status_pbyr'=>'diterima',
			'tanggal_pbyr'=>$this->input->post('tgl_pmbyrn'),
			'bukti_pbyr'=>'',
            'keterangan_pbyr'=>$this->input->post('jenis_pmbyrn'),
            'total_pembayaran'=>$this->input->post('jml_pmbyrn'));

       if($this->reservasi_model->pembayaran($store2db)==TRUE){

                 $this->session->set_flashdata('message','terimakasih sudah melakukan pembayaran');
                 redirect(base_url().'index.php/kasir/reservasi_controller/index');
        }else{
            $this->session->set_flashdata('message','maaf ada kesalahan');
            redirect(base_url().'index.php/kasir/reservasi_controller/index');
        }
      }
      $data['reservasi'] = $this->reservasi_model->ambil_reservasi(array('id_booking'=>$id_reservasi));
      $data['id_reservasi']=$id_reservasi;
      $data['content']='kasir/form_pembayaran_reservasi';
      $this->load->view('kasir/template_admin',$data);
  }

  function pembayaran2($id_reservasi){
      $booking = $this->reservasi_model->ambil_reservasi(array('booking.id_booking'=>$id_reservasi));
      $total = $booking[0]->harga_lapangan*$booking[0]->lama_pemakaian;
      $pembayaran = $this->reservasi_model->ambil_pembayaran(array('id_booking'=>$id_reservasi));
      $dibayar = isset($pembayaran[0])?$pembayaran[0]->total_pembayaran:0;
      $keterangan = isset($pembayaran[0])?$pembayaran[0]->keterangan_pbyr:'';
      $total_telah_dibayar = 0;
      $ket_bayar = "";
      $html = '';
      $html .='<form action="'.base_url().'index.php/kasir/reservasi_controller/tambah_pembayaran/'.$id_reservasi.'" method="post" enctype="multipart/form-data">
                <table>
		<tr><td><label>No Booking : </label></td>
                <td><input type="text" name="id_booking" value="'.$id_reservasi.'"></td>
                </tr>

		<tr><td><label>Tanggal Pembayaran</label></td>
		<td><input type="text" id="tgl_pmbyrn" name="tgl_pmbyrn" value="'.date('Y-m-d').'">
                <a href="javascript: NewCssCal(\'tgl_pmbyrn\',\'yyyymmdd\')"><img src="'. base_url('images/cal.gif').'"></a></td>
                </tr>
		<tr><td><label>Jumlah Harus dibayar</label></td>
		<td><input type="text" readonly value="Rp. '.number_format($total,0,'','.').'"></td>
                </tr>
                <tr><td><label>Jumlah Telah dibayar</label></td>
		<td><input type="text" readonly value="Rp. '.number_format($dibayar,0,'','.').'"></td>
                </tr>
                <tr><td><label>Keterangan</label></td>
		<td><input type="text" readonly value="'.$keterangan.'"></td>
                </tr>
		<tr><td><label>Jumlah Pembayaran</label></td>
		<td><input type="text" name="jml_pmbyrn" value=""></td>
                </tr>
                <tr><td><label>Jenis Pembayaran</label></td>
		<td><input type="radio" name="jenis_pmbyrn" value="pembayaran dp1">Pembayaran DP1<br><br>
                    <input type="radio" name="jenis_pmbyrn" value="lunas">Pembayaran Full<br><br>
                </td></tr>

		<tr><td><input type="submit" value="submit"></td></tr>

    </form>';
      echo json_encode(array('html'=>$html));
  }
  function tambah_pembayaran($id_reservasi){
      if($this->input->post()){
           $store2db = array(
                'id_booking'=>$this->input->post('id_booking'),
                'status_pbyr'=>'diterima',
                'tanggal_pbyr'=>$this->input->post('tgl_pmbyrn'),
                'bukti_pbyr'=>'',
                'keterangan_pbyr'=>$this->input->post('jenis_pmbyrn'),
                'total_pembayaran'=>$this->input->post('jml_pmbyrn'));
           $this->reservasi_model->pembayaran($store2db);
           $this->session->set_flashdata('script',"<script>$(document).ready(function(){
               $.ajax({
                url: 'http://localhost/ta/kasir/reservasi_controller/detail_reservasi/'+".$id_reservasi.",
                dataType : 'json',
                success: function(data){
                    $(\"#dialog\").html(data.html);
                }
            });
        $('#dialog').dialog('open');
               }); </script>");
           redirect(base_url('kasir/reservasi_controller/index'));
      }
  }
  function konfirmasi_pembayaran($id_reservasi,$id_pembayaran){
       $this->reservasi_model->konfirmasi_pembayaran($id_pembayaran,array('status_pbyr'=>'diterima'));
       $this->session->set_flashdata('script',"<script>$(document).ready(function(){
               $.ajax({
                url: 'http://localhost/ta/kasir/reservasi_controller/detail_reservasi/'+".$id_reservasi.",
                dataType : 'json',
                success: function(data){
                    $(\"#dialog\").html(data.html);
                }
            });
            $('#dialog').dialog('open');
               }); </script>");
        redirect(base_url('kasir/reservasi_controller/index'));
  }
  function detail_reservasi($id_reservasi=null){

      $html = $this->reservasi_model->get_detail_reservasi($id_reservasi);
      echo json_encode(array('html'=>$html));
  }
  function claim_refund($id_reservasi=null){
        if($this->reservasi_model->claim_refund($id_reservasi) == TRUE){
            $this->session->set_flashdata('script',"<script>$(document).ready(function(){
               $.ajax({
                url: 'http://localhost/ta/kasir/reservasi_controller/detail_reservasi/'+".$id_reservasi.",
                dataType : 'json',
                success: function(data){
                    $(\"#dialog\").html(data.html);
                }
            });
            $('#dialog').dialog('open');
               }); </script>");
         redirect(base_url('kasir/reservasi_controller/index'));
        }
       
  }


 }

?>
