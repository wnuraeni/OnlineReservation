<?php

//if ( !defined('BASEPATH')) exit ('No direct script access.');

class reservasi_model extends CI_Model{
    function __contruct(){
        parent :: __construct();
    }

function pesan($data){
    if($this->db->insert('booking',$data)){

        $var=$this->db->insert_id();

        return $var;
    }else {
        return false;
    }
}

function ambil_reservasi($where=null,$limit=10,$offset=0){
    $this->db->select('*');
    $this->db->from('booking');
    $this->db->join('lapangan','booking.id_lapangan=lapangan.id_lapangan');
    if(!empty($where)){
        $this->db->like($where);

    }
    $this->db->limit($limit,$offset);
    $this->db->order_by('booking.tanggal_booking','desc');

    $query=$this->db->get();
    return $query->result();
   
  }

function checkin($id_booking){
    $this->db->where('id_booking',$id_booking);
    $this->db->update('booking',array('status_booking'=>'checkin'));

}

function batal($id_booking=null,$data=null){
    //batal satu booking
    $this->db->where('id_booking',$id_booking);
    $this->db->update('booking',$data);
    
 }
function pembatalan($ids){
    //pembatalan beberapa booking sekaligus
//    $query = $this->db->get_where('booking',array('tanggal_booking < '=>date('Y-m-d'), 'status_pembayaran'=>'','status_booking'=>'booking'));
//    $result = $query->result();
    foreach($ids as $id){
        $this->db->where('id_booking',$id);
        $this->db->update('booking',array('status_booking'=>'batal'));
    }
}
 function ambil_total_reservasi($where=null){
     $this->db->select('*');
     $this->db->from('booking');
     if(!empty($where)){
         $this->db->like($where);
     }
    $query=$this->db->get();
     return $query->num_rows();
 }
function cek_reservasi(){
//ubah status booking klo belum bayar
//       $this->db->where('tanggal_booking <',$tanggal);
//$this->db->where('status_pembayaran !=','Lunas');
//       $this->db->update('booking',array('status_booking'=>'batal','status_pembayaran'=>'Belum dibayar'));
//echo $this->db->last_query();

// ambil data booking yang belum pada bayar
    $query = $this->db->get_where('booking',array('tanggal_booking < '=>date('Y-m-d'), 'status_pembayaran'=>'','status_booking'=>'booking'));
    return $query->result();
}
function cek_dp(){
    $query = $this->db->get_where('booking',array('tanggal_booking <= '=>date('Y-m-d'), 'status_pembayaran'=>'pembayaran dp1','status_booking'=>'booking'));
    return $query->result();
}

function pembayaran($data){
    $query1=$this->db->insert('pembayaran',$data);
 
    $this->db->where('id_booking',$data['id_booking']);
    $query2=$this->db->update('booking',
            array(
                'status_pembayaran'=>$data['keterangan_pbyr'],
                'tanggal_pembayaran'=>$data['tanggal_pbyr'],
                ));
    
    if($query1 && $query2 ){
        return true;
    }else {
        return false;
    }
}
function ambil_pembayaran($where=null){
    $this->db->select('id_booking,id_pembayaran,
        MIN(status_pbyr) as status_pbyr,
        MAX(tanggal_pbyr) as tanggal_pbyr, bukti_pbyr,
        MIN(keterangan_pbyr) as keterangan_pbyr,
        SUM(total_pembayaran) as total_pembayaran');
    $this->db->from('pembayaran');
    if(!empty($where)){
        $this->db->where($where);
    }
    $this->db->group_by('id_booking');
    $query = $this->db->get();
    return $query->result();
}
function konfirmasi_pembayaran($id_pembayaran,$data){
    //ambil keterangan klo dp2 update status jd lunas
    $query_keterangan = $this->db->get_where('pembayaran',array('id_pembayaran'=>$id_pembayaran));
    $result_keterangan = $query_keterangan->row();
    $keterangan =$result_keterangan->keterangan_pbyr;
    $id_booking = $result_keterangan->id_booking;
    
    if($keterangan == 'pembayaran dp2'){
        $this->db->where('id_booking',$id_booking);
        $this->db->update('booking',array('status_pembayaran'=>'lunas'));
    }
    $this->db->where('id_pembayaran',$id_pembayaran);
    $this->db->update('pembayaran',$data);

}
function ambil_konfirmasi_pembayaran($id_booking){
    $query = $this->db->query("SELECT booking.id_booking,`booking`.`harga_lapangan`, `booking`.`lama_pemakaian`,
            MAX(`pembayaran`.`status_pbyr`) as status_pbyr, MAX(pembayaran.tanggal_pbyr) as tanggal_pbyr,
            MAX(`pembayaran`.`bukti_pbyr`) as bukti_pbyr,
            MIN(`pembayaran`.`keterangan_pbyr`) as keterangan_pbyr,
            SUM(pembayaran.total_pembayaran) as total_pembayaran
            FROM (`booking`)
            LEFT JOIN `pembayaran` ON `pembayaran`.`id_booking`=`booking`.`id_booking`
            WHERE  `booking`.`id_booking`  = '$id_booking'
            GROUP BY `pembayaran`.`id_booking`");
    return $query->row();
}
function get_detail_reservasi($id_reservasi=null){
    $html = "";
    $data_reservasi = $this->ambil_reservasi(array('id_booking'=>$id_reservasi));
    $data_pembayaran = $this->ambil_detail_pembayaran(array('id_booking'=>$id_reservasi));
    $html .= '<table>
            <tr><td>No Booking</td><td>:</td><td>'.$data_reservasi[0]->id_booking.'</td></tr>
            <tr><td>Nama</td><td>:</td><td>'.$data_reservasi[0]->nama.'</td></tr>
            <tr><td>Alamat</td><td>:</td><td>'.$data_reservasi[0]->alamat.'</td></tr>
            <tr><td>Telepon</td><td>:</td><td>'.$data_reservasi[0]->telepon.'</td></tr>
            <tr><td>Tanggal booking</td><td>:</td><td>'.$data_reservasi[0]->tanggal_booking.'</td></tr>
            <tr><td>Jam mulai</td><td>:</td><td>'.$data_reservasi[0]->jam.'</td></tr>
            <tr><td>Nama Lapangan</td><td>:</td><td>'.$data_reservasi[0]->nama_lapangan.'</td></tr>
            <tr><td>Lama Pemakaian</td><td>:</td><td>'.$data_reservasi[0]->lama_pemakaian.'</td></tr>
            <tr><td>Biaya sewa perjam</td><td>:</td><td>Rp. '.number_format($data_reservasi[0]->harga_lapangan, 0,'','.').'</td></tr>
            <tr><td>Status Pembayaran</td><td>:</td><td>'.$data_reservasi[0]->status_pembayaran.'</td></tr>
            <tr><td>Status booking</td><td>:</td><td>'.$data_reservasi[0]->status_booking.'</td></tr>
            </table>
            <button class="button" onclick="pembayaran('.$id_reservasi.')">Tambah Pembayaran</button>
            <table>
            <tr><th>Tanggal Pembayaran</th><th>Jumlah Bayar</th><th>Bukti Pembayaran</th><th>Keterangan</th><th>Status Pembayaran</th><th>Aksi</th></tr>';
    foreach($data_pembayaran as $data){
            $html .= '<tr>
                <td>'.$data->tanggal_pbyr.'</td>
                <td>Rp. '.number_format($data->total_pembayaran, 0,'','.').'</td>
                <td>'.$data->bukti_pbyr.'</td>
                <td>'.$data->keterangan_pbyr.'</td>
                <td>'.$data->status_pbyr.'</td>
                <td>';
            if($data->status_pbyr != 'diterima'){
               $html .= '<a href="'.base_url().'index.php/kasir/reservasi_controller/konfirmasi_pembayaran/'.$id_reservasi.'/'.$data->id_pembayaran.'">Konfirmasi Penerimaan</a>';
            }
                $html .= '</td>
                </tr>';
    }
    $html .= '</table>
            <button onclick="window.location.href=\''.base_url().'index.php/kasir/reservasi_controller/claim_refund/'.$id_reservasi.'\'">Claim Refund</button>';
    return $html;
}
function claim_refund($id_reservasi=null){
    $query = $this->db->get_where('pembayaran',array('id_booking'=>$id_reservasi));
    $result = $query->result();
    $total = 0;
    foreach($result as $res){
        $total += $res->total_pembayaran;
    }
    $refund = 0.3 * $total;
    $this->db->where('id_booking',$id_reservasi);
    $query = $this->db->update('booking',
            array('status_pembayaran'=>'dikembalikan 30% dari pembayaran sejumlah : Rp. '.$refund
                 , 'status_booking'=>'batal'));
    if($query){
        return TRUE;
    }
    else{
        return FALSE;
    }
}

function ambil_detail_pembayaran($where=null){
    $this->db->select('id_booking,id_pembayaran,
        (status_pbyr) as status_pbyr,
        (tanggal_pbyr) as tanggal_pbyr, bukti_pbyr,
        (keterangan_pbyr) as keterangan_pbyr,
        (total_pembayaran) as total_pembayaran');
    $this->db->from('pembayaran');
    if(!empty($where)){
        $this->db->where($where);
    }
    $query = $this->db->get();
    return $query->result();
}

}
?>
