 <div class="col3">
                 <h4 class="heading colr">Welcome to PT X</h4>
        	<?php echo 'Terima Kasih Telah Mendaftar.....Silakan Login Kembali';?>
        </div>


