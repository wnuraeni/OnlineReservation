<h5>Terima Kasih Telah Melakukan Pesanan</h5>
<p>Silakan Datang 30 menit Sebelum Waktu yang telah Anda pesan</p>
<p>Simpan Bukti dibawah untuk Bukti Konfirmasi Pesanan</p>

<table>

<tr><td>Nama Lapangan</td><td><?php echo $reservasi[0]->nama_lapangan;?></td></tr>
<tr><td>Tanggal Sewa</td><td><?php echo $reservasi[0]->tanggal_booking;?></td></tr>
<tr><td>Jam Sewa</td><td><?php echo $reservasi[0]->jam;?></td></tr>
<tr><td>Lama Pemakaian</td><td><?php echo $reservasi[0]->lama_pemakaian;?></td></tr>
<tr><td>Nama</td><td><?php echo $reservasi[0]->nama;?></td></tr>
<tr><td>Alamat</td><td><?php echo $reservasi[0]->alamat;?></td></tr>
<tr><td>Telepon</td><td><?php echo $reservasi[0]->telepon;?></td></tr>
</table>

<button onclick="window.print()">Cetak</button>