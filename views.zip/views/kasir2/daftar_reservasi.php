<style>
input{
    float:left;
}

select{
    margin:0;
    margin-top:4px;
    padding:0;
    float:left;
    margin-left:20px;
}

.pagelink {
  float:right;
  margin-left:550px;
  margin-top:12px;

}
table thead,table tr{
    border:1px solid #ccc;
}
table{
    clear:left;
    margin-top:10px;
    text-align:center;
    width:100%;
}

</style>



  <div style="float:right"><form action="<?php echo base_url();?>kasir/reservasi_controller/index" method="post">
    <input type="text" name="keyword" placeholder="keyword..">
     <select name="kategori"><option value="booking.id_member">Id Member</option>
                             <option value="booking.nama">Nama</option>
     </select>
     <input type="submit" name="search" value="cari">
</form></div>
<br><br>

</form>
<div class="pagelink"><?php echo $this->pagination->create_links();?></div>
<br><br><br>

<table>
    <th>Nomer</th><th>Id Member</th><th>Nama Pelanggan</th><th>Alamat Pelanggan</th><th>Nama Lapangan</th><th>Jam Mulai</th><th>Lama Pemakaian</th><th>Tanggal Booking</th><th>Status</th><th>Status Pembayaran</th><th>Aksi</th>
    <?php $i=1; foreach($sewa as $s) :?>
    <tr>
     <td><?php echo $i ;?></td>
     <td><?php echo $s->id_member;?></td>
     <td><?php echo $s->nama ;?></td>
     <td><?php echo $s->alamat ;?></td>
     <!--<td><?php echo $s->telepon ;?></td> -->
     <td><?php echo $s->nama_lapangan ;?></td>
     <td><?php echo $s->jam ;?></td>
     <td><?php echo $s->lama_pemakaian." jam" ;?></td>
     <td><?php echo $s->tanggal_booking ;?></td>
     <td><?php echo $s->status_booking;?></td>
     <td><?php echo $s->status_pembayaran;?></td>
     <td><?php if($s->status_booking=='booking'):?>
          <a href="<?php echo base_url();?>kasir/reservasi_controller/checkin/<?php echo $s->id_booking ;?>">Masuk</a><?php endif ;?>
    <br><?php if($s->status_booking=='booking'):?>
          <a href="<?php echo base_url();?>kasir/reservasi_controller/batal/<?php echo $s->id_booking ;?>">Batal</a><?php endif ;?></td>

     </tr>
     <?php $i++; endforeach ;?>



</table>