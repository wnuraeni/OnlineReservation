<table>
	<tbody>
	<tr><td colspan="12"><big class="h2">Supplier</big></td></tr>
        <tr style="padding:50px">
	    
        <tr>
			<td>Id supplier</td>
            <td></td>
			<td> <input name="id_supplier" size="20" type="text" /></td>
		</tr>
	 
		<tr>
		<td>Nama</td>
            <td></td>
			<td> <input name="nama" size="20" type="text" /></td>
		</tr>
		<tr>
			<td>Alamat</td>
            <td></td>
			<td> <input name="alamat" size="20" type="text" /></td>
		</tr>
		<tr>
			<td>Kota</td>
            <td></td>
			<td> <input name="kota" size="20" type="text" /></td>
		</tr>      
        <tr>
			<td>Telepon</td>
            <td></td>
			<td> <input name="telepon" size="20" type="text" /></td>
		</tr>  
      
        
	<br /><br />
	<tr >
        <th style=" height:100%;"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kegiatan</h2></th>
		<th> </th>
		<th style=" height:100%;"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Paket Kegiatan</h2></th>
	</tr>
    
    	<tr> 
            <td></td>
			<td><input type="submit" id="contact-clear" value="Submit"/></td>
			<td></td>
		
	</tr>
	
	</tbody>
	</table>