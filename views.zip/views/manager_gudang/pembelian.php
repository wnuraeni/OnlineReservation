<table>
	<tbody>
	<tr><td colspan="12"><big class="h2">Pembelian</big></td></tr>
        <tr style="padding:50px">
	    
        <tr>
			<td>Id pembelian</td>
            <td></td>
			<td> <input name="id_pembelian" size="20" type="text" /></td>
		</tr>
	 
		<tr>
		<td>Tanggal pembelian</td>
            <td></td>
			<td> <input name="tglBeli" size="20" type="text" /></td>
		</tr>
		<tr>
			<td>Id supplier</td>
            <td></td>
			<td> <input name="id_supplier" size="20" type="text" /></td>
		</tr>
		<tr>
			<td>Nama supplier</td>
            <td></td>
			<td> <input name="nama_supplier" size="20" type="text" /></td>
		</tr>
        
        <tr>
			<td>Id barang</td>
            <td></td>
			<td> <input name="id_lapangan" size="20" type="text" /></td>
		</tr>  
        
        <tr>
			<td>Nama barang</td>
            <td></td>
			<td> <input name="nama_lapangan" size="20" type="text" /></td>
		</tr>  
        
        <tr>
			<td>Tipe barang</td>
            <td></td>
			<td> <input name="tipe_lapangan" size="20" type="text" /></td>
		</tr>  
        
        <tr>
			<td>Jumlah barang</td>
            <td></td>
			<td> <input name="jmlh_barang" size="20" type="text" /></td>
		</tr>  
        
        <tr>
			<td>Ukuran barang</td>
            <td></td>
			<td> <input name="ukuran_barang" size="20" type="text" /></td>
		</tr>  
        
        <tr>
			<td>Harga barang</td>
            <td></td>
			<td> <input name="jmlh_barang" size="20" type="text" /></td>
		</tr>  
        
        <tr>
			<td>Total harga barang</td>
            <td></td>
			<td> <input name="total_harga" size="20" type="text" /></td>
		</tr>  
        
        <tr>
			<td>Keterangan</td>
            <td></td>
			<td> <input name="keterangan" size="20" type="text" /></td>
		</tr>  
        
        
	<br /><br />
	<tr >
        <th style=" height:100%;"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kegiatan</h2></th>
		<th> </th>
		<th style=" height:100%;"><h2>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Paket Kegiatan</h2></th>
	</tr>
    
    	<tr> 
            <td></td>
			<td><input type="submit" id="contact-clear" value="Submit"/></td>
			<td></td>
		
	</tr>
	
	</tbody>
	</table>