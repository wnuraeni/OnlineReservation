<ul id="nav">
              
                <li>
                    <a class="collapsed heading">Jadwal</a>
                     <ul class="navigation">
                        <li><a href="<?php echo URL::base()?>application/classes/controller/berita.php" title="Jadwal Lapangan">Jadwal Lapangan</a></li>
                    </ul>
                </li>     
                
                 <li>
                    <a class="collapsed heading">News And Gallery</a>
                     <ul class="navigation">
                        <li><a href="<?php echo URL::base()?>application/views/news.php" title="News">News</a></li>
                        <li><a href="#" title="Event">Event</a></li>
                        <li><a href="#" title="Gallery">Gallery</a></li>
                    </ul>
                </li> 
                
                  <li>
                    <a class="collapsed heading">Perlengkapan Sewa</a>
                     <ul class="navigation">
                        <li><a href="<?php echo URL::base()?>ferani/application/views/news" title="Barang Sewa">Barang Sewa</a></li>
                        <li><a href="#" title="Barang Rusak">Barang Rusak</a></li>
                    </ul>
                </li>    
                
                <li>
                   <ul class="navigation">
                        <li class="heading selected">Pelanggan</li>
                    </ul>
                </li>
                
                <li>
                    <ul class="navigation">
                        <li class="heading selected">Karyawan</li>
                    </ul>
                </li>
                
                 
                
              
</ul>