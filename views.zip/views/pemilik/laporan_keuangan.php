<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
$this->load->view($search);
$this->load->view($isi);

?>
