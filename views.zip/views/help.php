<!-- Content Section -->
    <div id="content_sec" class="noback">
    	<!-- Column 3 Section -->
    	<div class="col3">
        	<!-- Static Section -->
        	<div class="static">

            	<h4 class="heading colr">Aturan PT Abadi</h4>
               <?php echo empty($text)?'':$text->content;?>
        </div>
    </div>
</div>

    <!-- Footer Section -->