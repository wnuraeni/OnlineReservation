<div class="reservasi">
<fieldset style="width:400px; float:left">
<form action="<?php echo base_url();?>kasir/reservasi_controller/book" method="post">
   <div class="inputboxes"><label>Id Member</label><input type="text" name="id_member" class="inputbox"></div>
    <div class="inputboxes"> <label>Nama Pelanggan </label><input type="text" name="nama_pelanggan" class="inputbox"></div>
     <div class="inputboxes"><label>Alamat Pelanggan </label><input type="text" name="alamat_pelanggan" class="inputbox"></div>
     <div class="inputboxes"> <label>Telepon Pelanggan </label><input type="text" name="telepon_pelanggan" class="inputbox"></div>
     <div class="inputboxes"> <label>Id Lapangan </label><input type="text" name="id_lapangan" value="<?php echo $id_lapangan;?>" class="inputbox"></div>
      <div class="inputboxes"><label>Nama Lapangan </label><input type="text" name="nama_lapangan" value="<?php echo $nama_lapangan;?>" class="inputbox"></div>
     <div class="inputboxes"> <label>Tanggal </label><input type="text" name="tanggal" value="<?php echo $tanggal;?>" class="inputbox"></div>
     <div class="inputboxes"><label>Jam  </label><input type="text" name="jam" value="<?php echo $jam;?>" class="inputbox"></div>
    <div class="inputboxes"> <label>Harga Sewa Lapangan  </label><input type="text" name="harga_sewa_lapangan" class="inputbox" value="<?php echo $harga_sewa_lapangan;?>"></div>
     <div class="inputboxes"><label>Lama Sewa Tersedia</label>
<!--         <input type="text" name="lama_sewa" class="inputbox">dalam jam-->
          <select name="lama_sewa">
        <option>-Pilih lama sewa-</option>
        <?php
        for($i=1;$i<=$lama_sewa;$i++){
            echo '<option value="'.$i.'">'.$i.' jam</option>';
        }
        ?>
    </select>
     </div>
    
    <input type="submit" name="sewa" value="sewa">
     <input type="button" name="back" value="back" onclick="window.location.href='<?php echo base_url().$this->session->userdata('back');?>'">

</form>
</fieldset>

<fieldset style="width:300px; float:left">
<table>
    <th>Nama Promosi</th><th>Diskon</th><th></th>
    <?php foreach($promosi as $promo):?>
    <tr><td><?php echo $promo->nama_promo;?></td>
        <td><?php echo $promo->diskon;?></td>
       <td><a href="#" onclick="apply_diskon('<?php echo $promo->diskon;?>')">Apply</a></td>
    </tr>
    <?php endforeach ;?>
</table>
</fieldset>

</div>


<script>
    function apply_diskon(diskon){
        var diskon=Number(diskon);
        var harga_awal=$('#harga_sewa').val();
        var harga_diskon=harga_awal*diskon;
        $('#harga_sewa').val(harga_awal-harga_diskon);
        $('a[onclick]').remove();
    }




   </script>

<style>
a {
    text-decoration:none;
}
.reservasi {
    height:600px;
}

</style>
