<style>
.calendar{
    font-family:Arial;
    font-size:12px;
}
table .calendar{
    margin:auto;
    border-collapse:collapse;

}
.calendar .days td{
    width:80px;
    height:80px;
    padding:4px;
    border:1px solid #999;
    vertical-align:top;
    background-color:#def;

}
.calendar .days td:hover{
    background-color:#fff;

}
.calendar .highlight{
    font-weight:bold;
    color:#00f;
    
}

</style>





<?php
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
echo $kalender


?>
