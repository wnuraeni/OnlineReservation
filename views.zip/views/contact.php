
    	<!-- Column1 Section -->
        <div class="col1">
        	<!-- Contact Section -->
        	<div class="contact">

            	<h4 class="heading colr">Contact Us</h4>
                <?php echo empty($text)?'':$text->content ;?>
               
            </div>
        </div>

