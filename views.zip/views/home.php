	<!-- Column1 Section -->
     
    	<!-- Column 3 Section -->
<div class="col3">
<h4 class="heading colr">Welcome to PT Abadi</h4>
<div style="font-size:14px" ><?php echo empty($text)?'':$text->content ;?></div>
</div>
    